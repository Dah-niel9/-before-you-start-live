export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    // Server-side research endpoint. The Tavily key never reaches the browser.
    if (url.pathname === "/api/research" && request.method === "POST") {
      return handleResearch(request, env);
    }

    // Normal website files are served by Cloudflare's existing static-assets layer.
    // The Worker is only needed for /api/research.
    return new Response("Not found", { status: 404 });
  },
};

async function handleResearch(request, env) {
  try {
    if (!env.TAVILY_API_KEY) {
      return json({ error: "Live Research is not configured yet." }, 500);
    }

    const body = await request.json();
    const name = String(body?.name || "").trim();
    const claim = String(body?.claim || "").trim();
    const url = String(body?.url || "").trim();
    const profile = body?.profile || {};

    if (!name || !claim) {
      return json({ error: "Opportunity name and claim are required." }, 400);
    }

    const query = buildResearchQuery(name, claim, url, profile);

    const tavilyResponse = await fetch("https://api.tavily.com/search", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        api_key: env.TAVILY_API_KEY,
        query,
        search_depth: "advanced",
        max_results: 5,
        include_answer: true,
        include_raw_content: false,
        include_images: false,
      }),
    });

    if (!tavilyResponse.ok) {
      const detail = await safeText(tavilyResponse);
      return json({
        error: "Live Research could not complete the search.",
        detail: detail.slice(0, 500),
      }, 502);
    }

    const data = await tavilyResponse.json();
    const results = Array.isArray(data.results) ? data.results : [];

    return json({
      ok: true,
      opportunity: name,
      query,
      answer: typeof data.answer === "string" ? data.answer : "",
      sources: results.slice(0, 5).map((item) => ({
        title: String(item.title || "Source"),
        url: String(item.url || ""),
        content: String(item.content || "").slice(0, 900),
        score: typeof item.score === "number" ? item.score : null,
      })),
      researchedAt: new Date().toISOString(),
    });
  } catch (error) {
    return json({
      error: "Live Research encountered an unexpected error.",
      detail: String(error?.message || error).slice(0, 300),
    }, 500);
  }
}

function buildResearchQuery(name, claim, url, profile) {
  const location = "Nigeria";
  const deviceList = Array.isArray(profile.devices) ? profile.devices.join(", ") : "";
  const budget = profile.budget || "";
  const goal = profile.goal || "";
  const suppliedUrl = url ? ` Official link: ${url}.` : "";

  return [
    `Investigate the online opportunity called "${name}" for a person in ${location}.`,
    `The opportunity claims: "${claim}".`,
    `Check whether the platform/opportunity is legitimate, what the work actually is,`,
    `whether people in Nigeria can currently use it, important requirements or KYC,`,
    `payment and withdrawal details, major costs, common complaints or risks, and`,
    `whether it looks worthwhile for someone with devices ${deviceList || "not specified"},`,
    `budget ${budget || "not specified"}, and goal ${goal || "not specified"}.`,
    `Prefer official sources and reputable independent sources. Clearly distinguish facts,`,
    `recent evidence, uncertainty, and user reports. Do not assume legitimacy from search presence.`,
    suppliedUrl,
  ].join(" ");
}

async function safeText(response) {
  try { return await response.text(); } catch { return ""; }
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      "content-type": "application/json; charset=UTF-8",
      "cache-control": "no-store",
    },
  });
}
