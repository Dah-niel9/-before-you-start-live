# Before You Start 🇳🇬 — V1 Final Polish

## Current V1 build
This ZIP is based on `Before_You_Start_V1_FINAL_HOME_COPY.zip` and preserves the existing V1 design, database, verdict system, profile fields, unknown-opportunity behavior, and interaction rules.

## Approved V1 changes
1. **Verified Opportunities → Check this Opportunity** now fills “What does it claim to offer?” with a factual opportunity claim rather than the opportunity's biggest catch.
2. **What We Considered** on the result page is reorganized into:
   - Opportunity
   - Requirements
   - Getting Paid
   - Earnings
   - Your Fit
3. **Three Checks** remains unchanged in principle:
   - Legitimacy
   - Accessibility
   - Worthwhile
4. **Real Cost** remains separate:
   - Cash cost
   - Data cost
   - Time cost
   - Opportunity cost

## Important V1 boundaries
- V1 remains static. Live research is **not** connected.
- Unknown opportunities still return **NOT ENOUGH RELIABLE EVIDENCE** rather than being treated as scams.
- No AI-man image was added back into the product UI.
- No unrelated redesign was made.

## Next step
After this ZIP is reviewed/approved: final QA → Cloudflare live deployment → live smoke test → freeze V1.


Final correction: top brand uses a horizontal transparent lockup matching the provided Trial 3 reference; hero artwork remains unchanged.
